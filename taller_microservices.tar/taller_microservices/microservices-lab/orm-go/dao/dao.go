package dao

import (
	"gorm.io/gorm"
)

var DB *gorm.DB
