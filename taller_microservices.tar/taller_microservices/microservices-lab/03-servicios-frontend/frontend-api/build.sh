#!/bin/bash

docker build -t frontend-api:latest .