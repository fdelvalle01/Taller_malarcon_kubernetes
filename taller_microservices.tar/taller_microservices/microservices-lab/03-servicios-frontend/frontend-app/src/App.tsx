import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        Crear nueva factura
        <input type='text'></input> Nombre
      </header>
      <div>
        
      </div>
    </div>
  );
}

export default App;
