# microservices-lab
Laboratorio de microservicios

## Instrucciones

Ingresar a la carpeta __01-kubernetes__ y ejecutar scripts `00-create-cluster.sh` y `01-create-backend.sh`
```shell
cd 01-kubernetes
./00-create-cluster.sh
./01-create-backend.sh
```